"""Generates a sample ecommerce dataset: data/raw_sales_data.csv (run once)."""
import random
from datetime import date, timedelta
from pathlib import Path
import csv

random.seed(42)
ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "data" / "raw_sales_data.csv"

# category -> sub_category -> [(product, unit_price, base_margin)]
CATALOG = {
    "Technology": {
        "Phones": [("Smartphone X1", 18000, 0.18), ("Smartphone Lite", 9500, 0.15), ("Phone Case Pro", 450, 0.45)],
        "Accessories": [("Wireless Earbuds", 2200, 0.30), ("Bluetooth Speaker", 3100, 0.28), ("Power Bank 20000mAh", 1800, 0.25), ("USB-C Cable", 350, 0.50)],
        "Laptops": [("Laptop Pro 14", 62000, 0.12), ("Laptop Air 13", 48000, 0.14)],
    },
    "Furniture": {
        "Chairs": [("Ergonomic Office Chair", 7800, 0.22), ("Gaming Chair", 11500, 0.20)],
        "Tables": [("Study Table", 5200, 0.18), ("Standing Desk", 14500, 0.16)],
        "Storage": [("Bookshelf 5-Tier", 4200, 0.24), ("Wardrobe Organizer", 3600, 0.26)],
    },
    "Fashion": {
        "Men": [("Cotton T-Shirt", 599, 0.42), ("Slim Fit Jeans", 1599, 0.38), ("Formal Shirt", 1299, 0.40)],
        "Women": [("Kurti Set", 1499, 0.40), ("Denim Jacket", 2299, 0.36), ("Handbag", 1899, 0.44)],
        "Footwear": [("Running Shoes", 2999, 0.32), ("Casual Sneakers", 2199, 0.34)],
    },
    "Home & Kitchen": {
        "Appliances": [("Mixer Grinder", 3200, 0.22), ("Air Fryer", 6500, 0.20), ("Electric Kettle", 1100, 0.30)],
        "Cookware": [("Non-Stick Pan Set", 2400, 0.35), ("Pressure Cooker", 1900, 0.33)],
        "Decor": [("Wall Clock", 899, 0.48), ("LED Lamp", 1250, 0.42)],
    },
    "Books & Stationery": {
        "Books": [("Data Analytics Handbook", 799, 0.35), ("Python Programming Guide", 650, 0.36)],
        "Stationery": [("Notebook Pack (5)", 380, 0.50), ("Gel Pen Set", 220, 0.55)],
    },
}
REGIONS = {"North": 0.22, "South": 0.30, "East": 0.16, "West": 0.24, "Central": 0.08}
FIRST = ["Aarav","Vivaan","Aditya","Sai","Arjun","Rohan","Karthik","Ravi","Suresh","Anil","Priya","Ananya","Divya","Sneha","Kavya","Meena","Pooja","Swathi","Harini","Neha","Isha","Sravani","Deepika","Manoj","Vikram","Naveen","Harsha","Teja","Charan"]
LAST = ["Reddy","Sharma","Kumar","Naidu","Rao","Patel","Singh","Gupta","Iyer","Nair","Das","Verma","Chowdary","Yadav","Mehta"]

customers = []
for i in range(1, 421):
    customers.append((f"C{i:04d}", f"{random.choice(FIRST)} {random.choice(LAST)}", random.choices(list(REGIONS), weights=REGIONS.values())[0]))

products = [(cat, sub, p, price, m) for cat, subs in CATALOG.items() for sub, items in subs.items() for p, price, m in items]

# seasonality (festive Oct-Dec) and yearly growth
MONTH_W = {1:0.9,2:0.8,3:0.95,4:0.9,5:1.0,6:1.1,7:1.05,8:1.0,9:1.1,10:1.5,11:1.7,12:1.5}
GROWTH = {2022: 1.0, 2023: 1.25, 2024: 1.55}

start, end = date(2022, 1, 1), date(2024, 12, 31)
days = [start + timedelta(d) for d in range((end - start).days + 1)]
weights = [MONTH_W[d.month] * GROWTH[d.year] for d in days]

rows = []
order_no = 10000
for d in random.choices(days, weights=weights, k=2600):
    order_no += 1
    cust_id, cust_name, region = random.choice(customers)
    for _ in range(random.choices([1, 2, 3, 4], weights=[50, 28, 15, 7])[0]):
        cat, sub, prod, price, margin = random.choice(products)
        qty = random.choices([1, 2, 3, 4, 5], weights=[50, 25, 13, 8, 4])[0]
        disc = random.choices([0, 0.05, 0.10, 0.20, 0.30, 0.40], weights=[40, 18, 16, 14, 8, 4])[0]
        sales = round(price * qty * (1 - disc), 2)
        profit = round(sales * (margin - 0.8 * disc) + random.uniform(-0.02, 0.02) * sales, 2)
        rows.append([f"ORD-{order_no}", d.isoformat(), cust_id, cust_name, prod, cat, sub, region, sales, qty, disc, profit])

# inject realistic dirt so the cleaning script has something to do
random.shuffle(rows)
for r in random.sample(rows, 60):
    rows.append(list(r))                          # duplicates
for r in random.sample(rows, 25):
    r[7] = ""                                     # missing region
for r in random.sample(rows, 15):
    r[8] = ""                                     # missing sales
for r in random.sample(rows, 30):
    r[4] = "  " + r[4] + " "                      # stray whitespace
random.shuffle(rows)

OUT.parent.mkdir(exist_ok=True)
with open(OUT, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["Order ID","Order Date","Customer ID","Customer Name","Product Name","Category","Sub-Category","Region","Sales","Quantity","Discount","Profit"])
    w.writerows(rows)
print(f"Generated {len(rows)} rows -> {OUT}")
